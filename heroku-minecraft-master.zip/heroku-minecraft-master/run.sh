#!/bin/bash

coffee proxy/connect.coffee frost-minecraft-server.herokuapp.com
